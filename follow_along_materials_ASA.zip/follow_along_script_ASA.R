# Loading packages we will need
library(brms)
library(ggplot2)
library(performance)
library(phonTools)
library(bayesplot)
library(tidyverse)
library(marginaleffects)

# Reading in the data
df <- read.csv("data/VOT_data.csv")

# Setting categorical variable as factor
df$L1 <- factor(df$L1,
                levels = c("Spanish", "English"))

# Setting contrasts to sum coding
contrasts(df$L1) <- contr.sum(2)/2

# Printing top ten rows to show structure
head(df, n = 10)

# Visualizing VOT by L1 group
ggplot(df, aes(x = VOT, fill = L1)) +
  geom_histogram(alpha = 0.5, position = "identity") +
  theme_bw(base_size = 25) +
  xlab("VOT (ms)") +
  scale_fill_brewer(palette = "Dark2")

# Loading Vowel Data
data(h95)

# Taking only the point vowels produced by adults
h95 <- h95[h95$type %in% c("m", "w") & h95$vowel %in% c("A", "i", "u"),]
h95 <- droplevels(h95)

# Plotting first formant from these vowels
ggplot(h95, aes(x = f1)) +
  geom_density() +
  geom_density(linewidth = 2) +
  theme_bw(base_size = 25) +
  xlab("F1 (Hz)")

# Fitting a model predicting F1 by men vs. women
f1_model_bad <- lm(log(f1) ~ type, data = h95)

# Getting the model predictions
p <- check_model(f1_model_bad, check = "pp_check", panel = FALSE)

# Creating base plot
p <- plot(p$PP_CHECK)

# Modifying plot of model predictions for presentation
p + theme_bw(base_size = 25) +
  labs(title = NULL,
       subtitle = NULL,
       x = "F1 (Hz)") +
  theme(legend.position = "top",
        plot.margin = margin(t = 5, r = 20, b = 5, l = 5))

# Add vowel + interaction to previous model
f1_model_better <- lm(log(f1) ~ vowel * type, data = h95)

# Creating model predictions for new model
p <- check_model(f1_model_better, check = "pp_check", panel = FALSE)

# Plotting
p <- plot(p$PP_CHECK)

# Modifying appearance and print ppcheck
p + theme_bw(base_size = 25) +
  labs(title = NULL,
       subtitle = NULL,
       x = "F1 (Hz)") +
  theme(legend.position = "top",
        plot.margin = margin(t = 5, r = 20, b = 5, l = 5))

# Setting up mixture of two normal distributions
two_normals <- mixture(gaussian(), gaussian(), order = TRUE)

# Saving our model formula
our_formula <- bf(VOT ~ L1, theta1 ~ L1)

# Setting wide priors
wide_priors <- c(
  prior(normal(0, 200), class = "Intercept", dpar = "mu1"), 
  prior(normal(0, 200), class = "Intercept", dpar = "mu2"), 
  prior(normal(0, 50), class = "sigma1"), 
  prior(normal(0, 50), class = "sigma2"), 
  prior(logistic(0, 1.5), class = "Intercept", dpar = "theta1"),
  prior(normal(0, 50), class = "b", dpar = "mu1"),
  prior(normal(0, 50), class = "b", dpar = "mu2"),
  prior(normal(0, 3), class = "b", dpar = "theta1")
)

# Fitting model with wide priors
first_try <- brm(formula = our_formula,
                 data = df,
                 family = two_normals,
                 prior = wide_priors,
                 cores = 8,
                 warmup = 500,
                 iter = 1000,
                 backend = "cmdstanr",
                 file = "models/first_try.rds")

# Posterior predictive check
pp_check(first_try, 
         ndraws = 11,
         type = "hist")

# Getting model draws
posterior <- as.array(first_try)
color_scheme_set("blue")

# Creating trace plots
p <- mcmc_trace(posterior, pars = c("b_mu1_Intercept", "b_mu2_Intercept"))

# Plotting trace plots
p + theme_bw(base_size = 25) +
  geom_line(linewidth = 1)

# Plotting posteriors from first model
posterior <- as_draws_df(first_try)

posterior %>%
  select("b_mu1_Intercept", "b_mu2_Intercept") %>%
  pivot_longer(cols = b_mu1_Intercept:b_mu2_Intercept,
               names_to = "Distribution",
               values_to = "draws") %>%
  ggplot(aes(x = draws, fill = Distribution, y = ..scaled..)) +
  geom_density(alpha = 0.7) +
  scale_fill_brewer(palette = "Set1") +
  xlab("Posterior draws (ms)") +
  ylab("Density (scaled)") +
  theme_bw(base_size = 25) +
  theme(legend.position = "top")

# Printing model summary
summary(first_try)

# Creating 
informed_priors <- c(
  prior(normal(-105, 10), class = "Intercept", dpar = "mu1"),
  prior(normal(5, 5), class = "Intercept", dpar = "mu2"), 
  prior(normal(0, 20), class = "sigma1"), 
  prior(normal(0, 2.5), class = "sigma2"), 
  prior(logistic(-2, 0.75), class = "Intercept", dpar = "theta1"),
  prior(normal(0, 15), class = "b", dpar = "mu1"),
  prior(normal(0, 10), class = "b", dpar = "mu2"),
  prior(normal(1, 1), class = "b", dpar = "theta1")
)

# Fitting model with informed priors
second_try <- brm(our_formula,
                  data = df,
                  family = two_normals,
                  prior = informed_priors,
                  cores = 8,
                  warmup = 500,
                  iter = 1000,
                  init = 0,
                  backend = "cmdstanr",
                  file = "models/second_try.rds")

summary(second_try)
plot(second_try)

# Posterior predictive checks
pp_check(second_try, 
         ndraws = 11,
         type = "hist")

# Interpreting our model
library(patchwork)

p1 <- plot_predictions(second_try, condition = "L1", dpar = "mu1")
p2 <- plot_predictions(second_try, condition = "L1", dpar = "mu2")
p3 <- plot_predictions(second_try, condition = "L1", dpar = "theta1")

p1 <- p1 + 
  theme_bw(base_size = 20) +
  ylab("Mean VOT pre-voiced /b/ (ms)")

p2 <- p2 + 
  theme_bw(base_size = 20) +
  ylab("Mean VOT short-lag /b/ (ms)")

p3 <- p3 + 
  theme_bw(base_size = 20) +
  ylab("Prob. of pre-voiced /b/")

# Printing out plots
p1 + p2 + p3
